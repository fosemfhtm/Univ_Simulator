Huge thanks to Improbable Studios for contributing this demo and a whole bunch of cool visual novel features for Fungus.

"Improbable studios is a global development staff composed of artists, writers,  programmers, and audio engineers from about 40 countries around the world. We are a non-profit organization dedicated to promoting interdisciplinary collaboration across country lines.
http://www.improbable-studios.com

This demo is part of a amazing project they are working on called "SHERLOCK: The Game is On".
http://www.improbable-studios.com/projects.html

=============

Many thanks to the talented Sara Mena who did additional work on the characters for this example.
http://saramena.com

=============

The content in this demo is licensed under the MIT open source license.

