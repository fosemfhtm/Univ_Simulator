This package contains Fungus Commands to support Spine by Esoteric Software
http://esotericsoftware.com/

Installation
============

1. Download and install the Spine runtime unitypackage in your Unity project
http://esotericsoftware.com/files/runtimes/unity/spine-unity.unitypackage

2. Install the spine.unitypackage in your Unity project. This file is located in the same folder as this text file.

3. Open the Fungus-Spine/Scenes/Dr Jeckle scene for an example of how to use the Spine commands

Usage
============

Use the Spine > Play Spine Animation command to play an animation on a Spine object.
Use the Spine > Stop Animation command to stop a playing animation on a Spine object.
